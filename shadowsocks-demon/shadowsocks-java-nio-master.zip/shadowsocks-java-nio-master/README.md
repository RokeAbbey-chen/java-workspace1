This is a shadowsocks-client project. Using java-nio to carry data in single thread.

Because single thread, its performance is not good. So it is my java nio study project.

For the crypto module, I refered the following project:
https://github.com/blakey22/shadowsocks-java

The project entry is 'NioClientServerSingleThread.java'. You can run main method to start.

The config file is 'config.json'. 

Only tested "aes-256-cfb" encryption.



