package com.nihao001.helloworld.utils;

public class Constant {
	public static final String 	CONFIG_FILE = "config.json";
	public static final int 	TIME_OUT 	= 1000 * 10;
	
	
}
