# WebSocketExplorer
Learn about WebSocket and explorer the theory

Required: Tomcat 7.0.67 (Build Path --> Configure Build Path --> Libraries --> Add Library --> Server Library)

