/**
 * 
 */
package io.nettythrift.core;

/**
 * @author HouKx
 * @date 2017年1月4日
 *
 */
public interface WriterHandlerFactory {

}
