/**
 * PACKAGE include TEST　CASES
 */
/**
 * @author HouKx
 *
 */
package io.nettythrift;