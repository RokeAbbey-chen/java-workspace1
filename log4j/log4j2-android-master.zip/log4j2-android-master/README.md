# log4j2-android
Log4j2 Android Example
